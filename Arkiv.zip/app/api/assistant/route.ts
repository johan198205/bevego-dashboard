// app/api/assistant/route.ts
import { NextResponse } from "next/server";
import OpenAI from "openai";
import {
  fetchKpis,
  fetchTimeseries,
  fetchCompareDates,
  fetchWeekdayAverages,
  fetchChannelBreakdown,
  ALL_KEYS,
  type MKey,
} from "../../../lib/ga4";

type ToolResult =
  | { type: "kpis"; data: Record<MKey, number> }
  | { type: "timeseries"; data: { labels: string[]; series: Record<MKey, number[]> } }
  | { type: "weekdayAverages"; data: Record<number, Record<MKey, number>> }
  | { type: "compareDates"; data: { A: Record<MKey, number>; B: Record<MKey, number> } }
  | {
      type: "channelBreakdown";
      data: {
        rows: Array<{ channel: string } & Record<MKey, number> & { share: Record<MKey, number> }>;
        totals: Record<MKey, number>;
      };
    };

const tools: any[] = [
  {
    type: "function",
    function: {
      name: "fetchKpis",
      description: "Get aggregated KPIs for a date range",
      parameters: {
        type: "object",
        properties: {
          startDate: { type: "string" },
          endDate: { type: "string" },
          metrics: { type: "array", items: { type: "string", enum: ALL_KEYS } },
        },
        required: ["startDate", "endDate", "metrics"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "fetchTimeseries",
      description: "Get per-day time series for metrics",
      parameters: {
        type: "object",
        properties: {
          startDate: { type: "string" },
          endDate: { type: "string" },
          metrics: { type: "array", items: { type: "string", enum: ALL_KEYS } },
        },
        required: ["startDate", "endDate", "metrics"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "fetchWeekdayAverages",
      description: "Get weekday averages for metrics over the last N weeks",
      parameters: {
        type: "object",
        properties: {
          endDate: { type: "string" },
          metrics: { type: "array", items: { type: "string", enum: ALL_KEYS } },
          weeks: { type: "number", default: 8 },
        },
        required: ["endDate", "metrics"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "fetchCompareDates",
      description: "Compare two specific dates on the same metrics",
      parameters: {
        type: "object",
        properties: {
          dateA: { type: "string" },
          dateB: { type: "string" },
          metrics: { type: "array", items: { type: "string", enum: ALL_KEYS } },
        },
        required: ["dateA", "dateB", "metrics"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "fetchChannelBreakdown",
      description: "Get sessionDefaultChannelGroup breakdown for a date range, with metrics.",
      parameters: {
        type: "object",
        properties: {
          startDate: { type: "string" },
          endDate: { type: "string" },
          metrics: { type: "array", items: { type: "string", enum: ALL_KEYS } },
        },
        required: ["startDate", "endDate"],
      },
    },
  },
];

function styleSeedFrom(str: string) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { message, thread = [], context } = (body || {}) as {
      message: string;
      thread?: { role: "user" | "assistant"; content: string }[];
      context?: { startDate?: string; endDate?: string };
    };

    if (!message) return NextResponse.json({ error: "message saknas" }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: "OPENAI_API_KEY saknas" }, { status: 500 });

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // Server-trim: skydda mot lååånga trådar
    const threadLimited = (thread || []).slice(-16);

    const styleSeed = styleSeedFrom(message + (context?.startDate || "") + (context?.endDate || ""));

    const messages: any[] = [
      {
        role: "system",
        content:
          "Du är en GA4-analytiker. Du får använda verktyg (functions) och får endast använda siffror från verktygsresultat. Variera stilen (kort, punktlista, Q&A, Insikt→Åtgärd). Svara på svenska, kompakt, utan fluff. Avsluta med 1–3 konkreta åtgärder.",
      },
      ...threadLimited,
      // Själva frågan + kontext som separat user-meddelande (ingen dubblering från klienten)
      { role: "user", content: JSON.stringify({ message, context }) },
    ];

    // Pass 1: plan + ev. tool calls
    let comp = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.6 + ((styleSeed % 10) / 100),
      messages,
      tools,
      tool_choice: "auto",
    });

    const toolResults: Record<string, ToolResult> = {};
    while (comp.choices[0].message.tool_calls?.length) {
      for (const call of comp.choices[0].message.tool_calls) {
        const args = JSON.parse(call.function.arguments || "{}");
        let result: ToolResult | null = null;

        switch (call.function.name) {
          case "fetchKpis":
            result = { type: "kpis", data: await fetchKpis(args.startDate, args.endDate, args.metrics as MKey[]) };
            break;
          case "fetchTimeseries":
            result = { type: "timeseries", data: await fetchTimeseries(args.startDate, args.endDate, args.metrics as MKey[]) };
            break;
          case "fetchWeekdayAverages":
            result = { type: "weekdayAverages", data: await fetchWeekdayAverages(args.endDate, args.metrics as MKey[], args.weeks || 8) };
            break;
          case "fetchCompareDates":
            result = { type: "compareDates", data: await fetchCompareDates(args.dateA, args.dateB, args.metrics as MKey[]) };
            break;
          case "fetchChannelBreakdown":
            result = {
              type: "channelBreakdown",
              data: await fetchChannelBreakdown(
                args.startDate,
                args.endDate,
                (args.metrics?.length ? args.metrics : ALL_KEYS) as MKey[]
              ),
            };
            break;
        }
        toolResults[call.id] = result!;
      }

      const toolMsgs = comp.choices[0].message.tool_calls.map((call) => ({
        role: "tool" as const,
        tool_call_id: call.id,
        content: JSON.stringify(toolResults[call.id]),
      }));

      comp = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        temperature: 0.65 + ((styleSeed % 10) / 100),
        messages: [...messages, comp.choices[0].message, ...toolMsgs],
      });
    }

    const rawAnswer = comp.choices[0].message.content?.trim() || "";

    // Pass 2: strukturera till { answerMarkdown, charts, tables }
    const summarizer = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            'Returnera JSON: {"answerMarkdown":string,"charts":[{"title":string,"type":"line|doughnut","labels":string[],"datasets":[{"label":string,"data":number[]}]}],"tables":[{"title":string,"columns":string[],"rows":string[][]}]}. Ändra inte siffror och inga extra fält.',
        },
        { role: "user", content: rawAnswer },
      ],
    });

    const payload =
      JSON.parse(summarizer.choices[0].message.content || "{}") ||
      { answerMarkdown: rawAnswer, charts: [], tables: [] };

    if (!payload.answerMarkdown) payload.answerMarkdown = rawAnswer;
    if (!payload.charts) payload.charts = [];
    if (!payload.tables) payload.tables = [];

    return NextResponse.json(payload);
  } catch (e: any) {
    console.error("assistant error:", e);
    return NextResponse.json({ error: e?.message || "assistant-fel" }, { status: 500 });
  }
}
