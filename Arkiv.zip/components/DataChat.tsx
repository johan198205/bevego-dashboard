// components/DataChat.tsx
"use client";

import React, { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Line, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

// Registrera allt som behövs för både line & doughnut
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, ArcElement, Tooltip, Legend);

type Msg = { role: "user" | "assistant"; content: string };

type ChartSpec = {
  title: string;
  type: "line" | "doughnut";
  labels: string[];
  datasets: { label: string; data: number[] }[];
};

type TableSpec = { title: string; columns: string[]; rows: string[][] };

type AssistantResp = { answerMarkdown: string; charts?: ChartSpec[]; tables?: TableSpec[] };

const LS_KEY = "ga4_chat_thread_v1";

export default function DataChat({
  defaultContext,
}: {
  defaultContext?: { startDate?: string; endDate?: string };
}) {
  const [thread, setThread] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [last, setLast] = useState<AssistantResp | null>(null);
  const [error, setError] = useState("");

  // Ladda tråd från localStorage (persistens i samma webbläsare)
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LS_KEY);
      if (saved) setThread(JSON.parse(saved));
    } catch {}
  }, []);
  // Spara tråden vid ändring
  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(thread));
    } catch {}
  }, [thread]);

  async function send() {
    const q = input.trim();
    if (!q) return;

    // Skicka INTE med senaste frågan i thread till API:t – undviker dubblering.
    const threadForApi = thread.slice(-12); // trimma till senaste 12 meddelanden
    const nextThread = [...thread, { role: "user" as const, content: q }];
    setThread(nextThread);
    setBusy(true);
    setError("");
    setLast(null);

    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q, thread: threadForApi, context: defaultContext }),
      });

      const ct = res.headers.get("content-type") || "";
      const data: AssistantResp | any = ct.includes("application/json")
        ? await res.json()
        : { error: await res.text() };

      if (!res.ok || data.error) {
        throw new Error(data.error || "Kunde inte få svar från assistenten.");
      }

      setLast(data);
      setThread((c) => [...c, { role: "assistant", content: data.answerMarkdown }]);
    } catch (e: any) {
      setError(e.message || "Fel i analysen");
    } finally {
      setBusy(false);
      setInput("");
    }
  }

  // Modern färgpalett
  const palette = ["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#14b8a6", "#f97316"];

  return (
    <div className="card modern-card" style={{ padding: 16 }}>
      <h2 style={{ fontWeight: 700, marginBottom: 8 }}>Fråga datan</h2>

      <div style={{ display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder="Ex: Vilka kanaler driver flest konverteringar senaste 30 dagarna?"
          style={{
            flex: 1,
            height: 40,
            border: "1px solid #e5e7eb",
            borderRadius: 8,
            padding: "0 12px",
          }}
        />
        <button className="btn" onClick={send} disabled={busy}>
          {busy ? "Analyserar..." : "Skicka"}
        </button>
      </div>

      {error && (
        <div style={{ color: "#b91c1c", marginTop: 12 }}>
          {error}
        </div>
      )}

      <div style={{ marginTop: 16, display: "grid", gap: 12 }}>
        {/* Tråd (text) */}
        {thread.map((m, i) => (
          <div
            key={i}
            className="card"
            style={{ padding: 12, background: m.role === "user" ? "#f9fafb" : "#fff" }}
          >
            <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 4 }}>
              {m.role === "user" ? "Du" : "Assist:"}
            </div>
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
          </div>
        ))}

        {/* Diagram (line/doughnut) från senaste svaret */}
        {last?.charts?.map((c, idx) => {
          if (c.type === "doughnut") {
            const bg = c.labels.map((_, i) => `${palette[i % palette.length]}cc`);
            const border = c.labels.map((_, i) => `${palette[i % palette.length]}`);
            const data = {
              labels: c.labels,
              datasets: c.datasets.map((d) => ({
                ...d,
                backgroundColor: bg,
                borderColor: border,
                borderWidth: 1,
              })),
            };
            return (
              <div key={`chart-${idx}`} className="card modern-card" style={{ padding: 16 }}>
                <div style={{ fontWeight: 700, marginBottom: 6 }}>{c.title}</div>
                <div style={{ height: 320 }}>
                  <Doughnut
                    data={data}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: { position: "right", labels: { usePointStyle: true, boxWidth: 8 } },
                        tooltip: { cornerRadius: 8, padding: 10, displayColors: true },
                      },
                    }}
                  />
                </div>
              </div>
            );
          }

          // Line-rendering
          const datasets = c.datasets.map((d, i) => {
            const color = palette[i % palette.length];
            return {
              ...d,
              borderColor: color,
              backgroundColor: `${color}33`, // 20% fill
              fill: true,
              tension: 0.35,
              borderWidth: 2.5,
              pointRadius: 2,
              pointHoverRadius: 4,
              pointBorderWidth: 0,
            };
          });

          return (
            <div key={`chart-${idx}`} className="card modern-card" style={{ padding: 16 }}>
              <div style={{ fontWeight: 700, marginBottom: 6 }}>{c.title}</div>
              <div style={{ height: 320 }}>
                <Line
                  data={{ labels: c.labels, datasets }}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: "index", intersect: false },
                    plugins: {
                      legend: { position: "top", labels: { usePointStyle: true, boxWidth: 8 } },
                      tooltip: { cornerRadius: 8, padding: 10, displayColors: true },
                    },
                    scales: {
                      x: { grid: { color: "#f1f5f9" }, ticks: { maxRotation: 0 } },
                      y: { beginAtZero: true, grid: { color: "#f1f5f9" } },
                    },
                    elements: { line: { borderCapStyle: "round" } },
                  }}
                />
              </div>
            </div>
          );
        })}

        {/* Tabeller (zebra + rundade hörn) */}
        {last?.tables?.map((t, idx) => (
          <div key={`table-${idx}`} className="card modern-card table-wrap" style={{ padding: 0 }}>
            <div style={{ padding: "12px 16px", fontWeight: 700 }}>{t.title}</div>
            <table>
              <thead>
                <tr>
                  {t.columns.map((h, i) => (
                    <th key={i}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {t.rows.map((r, ri) => (
                  <tr key={ri}>
                    {r.map((cell, ci) => (
                      <td key={ci}>{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>

      {/* Snyggare styling */}
      <style jsx global>{`
        .btn {
          background: #111827;
          color: white;
          border: 0;
          border-radius: 10px;
          height: 40px;
          padding: 0 14px;
          cursor: pointer;
        }
        .btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .modern-card {
          border-radius: 16px !important;
          box-shadow: 0 6px 24px rgba(0, 0, 0, 0.06);
        }
        .table-wrap {
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          overflow: hidden;
        }
        .table-wrap table {
          width: 100%;
          border-collapse: collapse;
          font-size: 14px;
        }
        .table-wrap thead th {
          background: #f8fafc;
          padding: 10px 12px;
          text-align: left;
          font-weight: 700;
          color: #475569;
          text-transform: uppercase;
          letter-spacing: 0.02em;
          border-bottom: 1px solid #e5e7eb;
        }
        .table-wrap tbody td {
          padding: 10px 12px;
          border-bottom: 1px solid #f1f5f9;
        }
        .table-wrap tbody tr:nth-child(even) {
          background: #fafafa;
        }
        .table-wrap tbody tr:hover {
          background: #f3f4f6;
        }
      `}</style>
    </div>
  );
}
