"use client";

import { useEffect, useMemo, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

type Row = {
  channel: string;
  sessions: number;
  totalUsers: number;
  conversions: number;
  averageSessionDuration: number;
  share: {
    sessions: number;
    totalUsers: number;
    conversions: number;
    averageSessionDuration: number;
  };
};

export default function ChannelWidget({ startDate, endDate }: { startDate: string; endDate: string }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function load() {
    setLoading(true); setErr("");
    try {
      const res = await fetch("/api/channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startDate, endDate }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Kunde inte hämta kanaldata.");
      setRows(data.rows || []);
    } catch (e:any) { setErr(e.message || "Fel vid hämtning av kanaldata."); }
    finally { setLoading(false); }
  }
  useEffect(()=>{ load(); /* eslint-disable-next-line */ }, [startDate, endDate]);

  // Palett
  const palette = ["#6366f1","#10b981","#f59e0b","#ef4444","#8b5cf6","#06b6d4","#14b8a6","#f97316","#84cc16","#0ea5e9"];

  const pieSessions = useMemo(() => {
    if (!rows.length) return null;
    const labels = rows.map(r => r.channel);
    const data = rows.map(r => r.sessions);
    const bg = labels.map((_,i)=> `${palette[i % palette.length]}cc`);
    const border = labels.map((_,i)=> `${palette[i % palette.length]}`);
    return {
      labels,
      datasets: [{ label: "Sessioner", data, backgroundColor: bg, borderColor: border, borderWidth: 1 }]
    };
  }, [rows]);

  return (
    <section className="card modern-card" style={{ padding: 16 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom: 8 }}>
        <h2 style={{ fontWeight: 700 }}>Trafikkanaler</h2>
        <button className="btn" onClick={load} disabled={loading}>{loading ? "Laddar…" : "Uppdatera"}</button>
      </div>

      {err && <div style={{ color:"#b91c1c", marginBottom: 8 }}>{err}</div>}

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
        <div className="table-wrap" style={{ padding: 0 }}>
          <table>
            <thead>
              <tr>
                <th>Kanal</th>
                <th style={{ textAlign:"right" }}>Sessioner</th>
                <th style={{ textAlign:"right" }}>Användare</th>
                <th style={{ textAlign:"right" }}>Konverteringar</th>
                <th style={{ textAlign:"right" }}>Andel (Sessions)</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r,i)=>(
                <tr key={i}>
                  <td>{r.channel}</td>
                  <td style={{ textAlign:"right" }}>{r.sessions.toLocaleString("sv-SE")}</td>
                  <td style={{ textAlign:"right" }}>{r.totalUsers.toLocaleString("sv-SE")}</td>
                  <td style={{ textAlign:"right" }}>{r.conversions.toLocaleString("sv-SE")}</td>
                  <td style={{ textAlign:"right", fontWeight:700 }}>{(r.share.sessions*100).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card modern-card" style={{ padding: 16 }}>
          <div style={{ fontWeight: 700, marginBottom: 6 }}>Fördelning av sessioner</div>
          <div style={{ height: 340 }}>
            {pieSessions ? (
              <Doughnut
                data={pieSessions}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "right", labels: { usePointStyle: true, boxWidth: 8 } },
                    tooltip: { cornerRadius: 8, padding: 10, displayColors: true },
                  }
                }}
              />
            ) : (
              <div>Ingen data.</div>
            )}
          </div>
        </div>
      </div>

      <style jsx global>{`
        .table-wrap { border: 1px solid #e5e7eb; border-radius: 12px; overflow: hidden; }
        .table-wrap table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .table-wrap thead th { background: #f8fafc; padding: 10px 12px; text-align: left; font-weight: 700; color: #475569; border-bottom: 1px solid #e5e7eb; }
        .table-wrap tbody td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; }
        .table-wrap tbody tr:nth-child(even) { background: #fafafa; }
        .table-wrap tbody tr:hover { background: #f3f4f6; }
      `}</style>
    </section>
  );
}
